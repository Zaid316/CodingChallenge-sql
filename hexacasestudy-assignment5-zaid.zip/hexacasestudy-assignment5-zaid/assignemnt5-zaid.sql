use db2;
CREATE TABLE Artists (
 ArtistID INT PRIMARY KEY,
 Name VARCHAR(255) NOT NULL,
 Biography TEXT,
 Nationality VARCHAR(100));
 
 CREATE TABLE Categories (
 CategoryID INT PRIMARY KEY,
 Name VARCHAR(100) NOT NULL);
 
 CREATE TABLE Artworks (
 ArtworkID INT PRIMARY KEY,
 Title VARCHAR(255) NOT NULL,
 ArtistID INT,
 CategoryID INT,
 Year INT,
 Description TEXT,
 ImageURL VARCHAR(255),
 FOREIGN KEY (ArtistID) REFERENCES Artists (ArtistID),
 FOREIGN KEY (CategoryID) REFERENCES Categories (CategoryID));
 
 CREATE TABLE Exhibitions (
 ExhibitionID INT PRIMARY KEY,
 Title VARCHAR(255) NOT NULL,
 StartDate DATE,
 EndDate DATE,
 Description TEXT);
 
 CREATE TABLE ExhibitionArtworks (
 ExhibitionID INT,
 ArtworkID INT,
 PRIMARY KEY (ExhibitionID, ArtworkID),
 FOREIGN KEY (ExhibitionID) REFERENCES Exhibitions (ExhibitionID),
 FOREIGN KEY (ArtworkID) REFERENCES Artworks (ArtworkID));
 
 INSERT INTO Artists (ArtistID, Name, Biography, Nationality) VALUES
 (1, 'Pablo Picasso', 'Renowned Spanish painter and sculptor.', 'Spanish'),
 (2, 'Vincent van Gogh', 'Dutch post-impressionist painter.', 'Dutch'),
 (3, 'Leonardo da Vinci', 'Italian polymath of the Renaissance.', 'Italian');
 
 INSERT INTO Categories (CategoryID, Name) VALUES
 (1, 'Painting'),
 (2, 'Sculpture'),
 (3, 'Photography');
 
 INSERT INTO Artworks (ArtworkID, Title, ArtistID, CategoryID, Year, Description, ImageURL) VALUES
 (1, 'Starry Night', 2, 1, 1889, 'A famous painting by Vincent van Gogh.', 'starry_night.jpg'),
 (2, 'Mona Lisa', 3, 1, 1503, 'The iconic portrait by Leonardo da Vinci.', 'mona_lisa.jpg'),
 (3, 'Guernica', 1, 1, 1937, 'Pablo Picasso\'s powerful anti-war mural.', 'guernica.jpg');
 
 INSERT INTO Exhibitions (ExhibitionID, Title, StartDate, EndDate, Description) VALUES
 (1, 'Modern Art Masterpieces', '2023-01-01', '2023-03-01', 'A collection of modern art masterpieces.'),
 (2, 'Renaissance Art', '2023-04-01', '2023-06-01', 'A showcase of Renaissance art treasures.');
 
 INSERT INTO ExhibitionArtworks (ExhibitionID, ArtworkID) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 2);

select artists.name, count(artworks.artworkid) as num_art from artists, artworks where artists.artistid = artworks.artistid group by artists.name order by num_art;
select title from artworks,artists where artists.artistid = artworks.artistid and nationality in ("spanish","dutch") order by year;
select artists.name, count(artworks.artworkid) from artworks, artists, categories where artists.artistid = artworks.artistid and artworks.categoryid = categories.categoryid and categories.name = 'painting'group by artists.artistid, artists.name;
SELECT artworks.title, artists.name as artist, categories.name as category from artworks join exhibitionartworks ON artworks.artworkID = exhibitionartworks.artworkid join exhibitions ON exhibitionartworks.exhibitionid = exhibitions.exhibitionid join artists ON artworks.artistID = artists.artistID JOIN Categories ON Artworks.CategoryID = Categories.CategoryID WHERE Exhibitions.Title = 'Modern Art Masterpieces';
select name from artists where artistid in (select artistid from artworks group by artistid having count(*) > 2);
select title from artworks where artistid in(select artworkid from exhibitionartworks group by artworkid having count(*) >1); 
select categories.name, count(artworks.artworkid) from artworks,categories where artworks.categoryid = categories.categoryid group by categories.name;
select name from artists where artistid in (select artistid from artworks group by artistid having count(*)>3);
select title from artworks where artistid in (select artistid from artists where nationality = "Spanish");
#10
select title from artworks where artworkid not in (select artworkid from exhibitionartworks);
#12
select categories.Name, COUNT(Artworks.ArtworkID) from categories left join artworks ON categories.categoryid = artworks.categoryid GROUP BY categories.categoryID;
#14
select categories.name , avg(artworks.year) from categories join artworks on categories.categoryid = artworks.categoryid group by categories.categoryid having count(artworks.categoryid) > 1; 
select artworks.title from artworks join exhibitionartworks on artworks.artworkid = exhibitionartworks.artworkid join exhibitions ON exhibitionartworks.exhibitionid = exhibitions.exhibitionid WHERE exhibitions.title = 'modern art masterpieces';
select categories.name, categories.categoryid from categories, artworks where categories.categoryid = artworks.categoryid group by categories.categoryid having avg(artworks.year) > (select avg(year) from artworks);
select title from artworks where artworkid not in (select exhibitionartworks.artworkid from exhibitionartworks);
select distinct name from artists where artistid in(select artistid from artworks where categoryid = (select categoryid from artworks where title = 'mona lisa'));
select artists.name, count(exhibitionartworks.artworkid) from artists,artworks,exhibitionartworks where Artists.ArtistID = Artworks.ArtistID and Artworks.ArtworkID = ExhibitionArtworks.ArtworkID group by artists.name;